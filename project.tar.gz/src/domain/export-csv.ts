import { db } from "./db";

const BOM = "\uFEFF";

function csvLine(cells: (string | number)[]): string {
  return cells
    .map((c) => {
      const s = String(c ?? "");
      if (s.includes(",") || s.includes('"') || s.includes("\n")) {
        return `"${s.replace(/"/g, '""')}"`;
      }
      return s;
    })
    .join(",");
}

function downloadCsv(filename: string, headers: string[], rows: (string | number)[][]): void {
  const content = BOM + [csvLine(headers), ...rows.map(csvLine)].join("\n");
  const blob = new Blob([content], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function delay(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

const today = () => new Date().toISOString().slice(0, 10);

// ── 导出全部为 CSV（分别下载，6 个文件）──
export async function exportAllCsv(): Promise<void> {
  const [skuMaster, inventoryLayer, campaigns, promotions, alerts, todos] = await Promise.all([
    db.skuMaster.toArray(),
    db.inventoryLayer.toArray(),
    db.campaigns.toArray(),
    db.promotions.toArray(),
    db.alerts.toArray(),
    db.todos.toArray(),
  ]);

  const dateStr = today();

  // 1. SKU主数据
  const skuHeaders = [
    "品名", "SKU", "MSKU", "ASIN", "UPC", "父体ASIN", "父体SKU", "所属父SKU分组",
    "链接类型", "销售情况", "仓库类型", "所属店铺", "站点", "品类",
    "售价", "ListPrice", "优惠券",
    "FOB", "头程", "配送费", "佣金", "仓储费", "广告费", "退货费",
    "包裹长(cm)", "包裹宽(cm)", "包裹高(cm)", "包裹重(kg)", "单箱数",
    "LeadTime(天)", "安全库存(天)", "产品链接",
    "A+", "高级A+", "安装视频", "透明计划",
    "生命周期", "上架日期",
  ];
  const skuRows = skuMaster.map((s) => [
    s.name, s.sku, s.msku ?? "", s.asin ?? "", s.upc ?? "", s.parentAsin ?? "", s.parentSku ?? "", s.groupSku ?? "",
    s.linkType ?? "", s.saleStatus, s.fulfillment, s.store, s.marketplace ?? "", s.category ?? "",
    s.price, s.listPrice ?? "", s.coupon ?? "",
    s.costFob ?? "", s.costShipping ?? "", s.costDelivery ?? "", s.costCommission ?? "",
    s.costStorage ?? "", s.costAd ?? "", s.costReturn ?? "",
    s.packageLength ?? "", s.packageWidth ?? "", s.packageHeight ?? "", s.packageWeight ?? "", s.unitsPerBox ?? "",
    s.leadTimeDays ?? "", s.safetyStockDays ?? "", s.productUrl ?? "",
    s.aPlus ?? "", s.aPlusAdvanced ?? "", s.installVideo ?? "", s.transparentPlan ?? "",
    s.lifecycle ?? "", s.launchDate ?? "",
  ]);
  downloadCsv(`SKU主数据-${dateStr}.csv`, skuHeaders, skuRows);
  await delay(300);

  // 2. 成本明细
  const costHeaders = [
    "SKU", "品名", "售价", "FOB", "头程", "配送费", "佣金", "仓储费", "广告费", "退货费", "优惠券",
    "总成本", "单件净利", "净利率(%)",
  ];
  const costRows = skuMaster.map((s) => {
    const fob = s.costFob ?? 0;
    const shipping = s.costShipping ?? 0;
    const delivery = s.costDelivery ?? 0;
    const commission = s.costCommission ?? 0;
    const storage = s.costStorage ?? 0;
    const ad = s.costAd ?? 0;
    const ret = s.costReturn ?? 0;
    const coupon = s.coupon ?? 0;
    const totalCost = fob + shipping + delivery + commission + storage + ad + ret + coupon;
    const profit = s.price - totalCost;
    const margin = s.price > 0 ? ((profit / s.price) * 100) : 0;
    return [
      s.sku, s.name, s.price, fob, shipping, delivery, commission, storage, ad, ret, coupon,
      Number(totalCost.toFixed(2)), Number(profit.toFixed(2)), Number(margin.toFixed(1)),
    ];
  });
  downloadCsv(`成本明细-${dateStr}.csv`, costHeaders, costRows);
  await delay(300);

  // 3. 发货决策
  const invHeaders = [
    "SKU", "品名", "日期", "FBA在库", "FBM在库", "工厂库存",
    "美东在途", "美西在途", "美东南在途", "美中南在途",
    "美东在库", "美西在库", "美东南在库", "美中南在库",
    "在途批次", "工厂批次",
  ];
  const invRows = inventoryLayer.map((inv) => {
    const transitSummary = inv.transitBatches
      ? inv.transitBatches.map((b) => `${b.warehouse}:${b.qty}(${b.etaDate})`).join("; ")
      : "";
    const factorySummary = inv.factoryBatches
      ? inv.factoryBatches.map((b) => `${b.factoryName}:${b.qty}(交期${b.deliveryDate})`).join("; ")
      : "";
    const sku = skuMaster.find((s) => s.sku === inv.sku);
    return [
      inv.sku, sku?.name ?? "", inv.date,
      inv.fbaStock, inv.fbmStock, inv.factoryStock ?? 0,
      inv.eastTransit, inv.westTransit, inv.southeast, inv.southcentral,
      inv.eastStock ?? 0, inv.westStock ?? 0, inv.southeastStock ?? 0, inv.southcentralStock ?? 0,
      transitSummary, factorySummary,
    ];
  });
  downloadCsv(`发货决策-${dateStr}.csv`, invHeaders, invRows);
  await delay(300);

  // 4. 待办
  const todoHeaders = ["标题", "关联SKU", "截止日", "状态", "创建时间", "完成时间"];
  const todoRows = todos.map((t) => [
    t.content, t.relatedSku ?? "", t.dueDate ?? "",
    t.completed ? "已完成" : "未完成", t.createdAt, t.completedAt ?? "",
  ]);
  downloadCsv(`待办-${dateStr}.csv`, todoHeaders, todoRows);
  await delay(300);

  // 5. 促销活动
  const promoHeaders = ["名称", "SKU", "品名", "店铺", "类型", "开始", "结束", "状态", "备注"];
  const promoRows = promotions.map((p) => [
    p.name, p.sku, p.skuName ?? "", p.store, p.type,
    p.startDate, p.endDate, p.status, p.notes ?? "",
  ]);
  downloadCsv(`促销活动-${dateStr}.csv`, promoHeaders, promoRows);
  await delay(300);

  // 6. 周数据快照
  const dailySnapshots = await db.dailySnapshot.toArray();
  const snapHeaders = [
    "日期", "SKU", "品名",
    "近7天日均销量", "近30天销量",
    "在库库存", "在途库存", "在库覆盖天数", "含在途覆盖天数",
    "广告花费", "广告费比(%)", "利润", "利润率(%)", "总成本",
    "评分", "评论数", "退货率(%)", "退款率(%)",
  ];
  const snapRows = dailySnapshots.map((snap) => {
    const sku = skuMaster.find((s) => s.sku === snap.sku);
    return [
      snap.date, snap.sku, sku?.name ?? "",
      snap.dailySales7d, snap.monthlySales,
      snap.stockOnHand, snap.stockInTransit,
      snap.daysOfCoverOnHand, snap.daysOfCoverWithTransit,
      snap.adSpend, snap.adRatio, snap.profit, snap.profitMargin, snap.totalCost,
      snap.rating, snap.reviewCount ?? "", snap.returnRate, snap.refundRate ?? "",
    ];
  });
  downloadCsv(`周数据快照-${dateStr}.csv`, snapHeaders, snapRows);
}

// ── 单板块 CSV 导出 ──
export async function exportSkuMasterCsv(): Promise<void> {
  const skuMaster = await db.skuMaster.toArray();
  const dateStr = today();
  const headers = ["品名", "SKU", "MSKU", "ASIN", "销售情况", "仓库类型", "所属店铺", "售价", "FOB", "头程", "配送费", "佣金", "仓储费", "广告费", "退货费"];
  const rows = skuMaster.map((s) => [
    s.name, s.sku, s.msku ?? "", s.asin ?? "", s.saleStatus, s.fulfillment, s.store,
    s.price, s.costFob ?? "", s.costShipping ?? "", s.costDelivery ?? "",
    s.costCommission ?? "", s.costStorage ?? "", s.costAd ?? "", s.costReturn ?? "",
  ]);
  downloadCsv(`SKU主数据-${dateStr}.csv`, headers, rows);
}

export async function exportCostCsv(): Promise<void> {
  const skuMaster = await db.skuMaster.toArray();
  const dateStr = today();
  const headers = ["SKU", "品名", "售价", "FOB", "头程", "配送费", "佣金", "仓储费", "广告费", "退货费", "优惠券", "总成本", "单件净利", "净利率(%)"];
  const rows = skuMaster.map((s) => {
    const fob = s.costFob ?? 0;
    const shipping = s.costShipping ?? 0;
    const delivery = s.costDelivery ?? 0;
    const commission = s.costCommission ?? 0;
    const storage = s.costStorage ?? 0;
    const ad = s.costAd ?? 0;
    const ret = s.costReturn ?? 0;
    const coupon = s.coupon ?? 0;
    const totalCost = fob + shipping + delivery + commission + storage + ad + ret + coupon;
    const profit = s.price - totalCost;
    const margin = s.price > 0 ? ((profit / s.price) * 100) : 0;
    return [s.sku, s.name, s.price, fob, shipping, delivery, commission, storage, ad, ret, coupon, Number(totalCost.toFixed(2)), Number(profit.toFixed(2)), Number(margin.toFixed(1))];
  });
  downloadCsv(`成本明细-${dateStr}.csv`, headers, rows);
}

export async function exportShipmentCsv(): Promise<void> {
  const [skuMaster, inventoryLayer] = await Promise.all([db.skuMaster.toArray(), db.inventoryLayer.toArray()]);
  const dateStr = today();
  const headers = ["SKU", "品名", "日期", "FBA在库", "FBM在库", "工厂库存", "美东在途", "美西在途", "美东南在途", "美中南在途"];
  const rows = inventoryLayer.map((inv) => {
    const sku = skuMaster.find((s) => s.sku === inv.sku);
    return [inv.sku, sku?.name ?? "", inv.date, inv.fbaStock, inv.fbmStock, inv.factoryStock ?? 0, inv.eastTransit, inv.westTransit, inv.southeast, inv.southcentral];
  });
  downloadCsv(`发货决策-${dateStr}.csv`, headers, rows);
}

export async function exportTodoCsv(): Promise<void> {
  const todos = await db.todos.toArray();
  const dateStr = today();
  const headers = ["标题", "关联SKU", "截止日", "状态", "创建时间"];
  const rows = todos.map((t) => [t.content, t.relatedSku ?? "", t.dueDate ?? "", t.completed ? "已完成" : "未完成", t.createdAt]);
  downloadCsv(`待办-${dateStr}.csv`, headers, rows);
}

export async function exportPromoCsv(): Promise<void> {
  const promotions = await db.promotions.toArray();
  const dateStr = today();
  const headers = ["名称", "SKU", "品名", "店铺", "类型", "开始", "结束", "状态"];
  const rows = promotions.map((p) => [p.name, p.sku, p.skuName ?? "", p.store, p.type, p.startDate, p.endDate, p.status]);
  downloadCsv(`促销活动-${dateStr}.csv`, headers, rows);
}

export async function exportSnapshotCsv(): Promise<void> {
  const [skuMaster, snapshots] = await Promise.all([db.skuMaster.toArray(), db.dailySnapshot.toArray()]);
  const dateStr = today();
  const headers = ["日期", "SKU", "品名", "近7天日均销量", "近30天销量", "广告费比(%)", "退货率(%)", "评分"];
  const rows = snapshots.map((snap) => {
    const sku = skuMaster.find((s) => s.sku === snap.sku);
    return [snap.date, snap.sku, sku?.name ?? "", snap.dailySales7d, snap.monthlySales, snap.adRatio, snap.returnRate, snap.rating];
  });
  downloadCsv(`周数据快照-${dateStr}.csv`, headers, rows);
}